//definimos la clase usuario
class Usuario{
    constructor(nombre, apellido, password, email){
    this.nombre = nombre;
    this.apellido = apellido;
    this.password = password;
    this.email = email;
}
}